// Kotha service worker - app shell cache (offline start) - A app by Md. Fardin Fahim
const V = "kotha-v2.0.0";
const SHELL = ["./", "index.html", "css/style.css", "favicon.svg", "manifest.webmanifest", "icons/icon-192.png", "icons/icon-512.png",
  "js/main.js", "js/config.js", "js/firebase.js", "js/state.js", "js/utils.js", "js/auth.js", "js/chat.js", "js/call.js", "js/meet.js",
  "js/geo.js", "js/people.js", "js/settings.js", "js/groups.js", "js/attach.js", "js/prefs.js"];
self.addEventListener("install", e => { e.waitUntil(caches.open(V).then(c => c.addAll(SHELL).catch(() => {})).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== V).map(x => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET" || u.origin !== location.origin) return;
  // network-first for our own files so updates show immediately, cache as offline fallback
  e.respondWith(fetch(e.request).then(r => { const cp = r.clone(); caches.open(V).then(c => c.put(e.request, cp)); return r; }).catch(() => caches.match(e.request).then(r => r || caches.match("index.html"))));
});
