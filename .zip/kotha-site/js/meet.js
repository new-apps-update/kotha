// Group calls / meetings: WebRTC mesh (up to MEET_MAX people), signalling through Firestore.
import { db, doc, setDoc, getDoc, updateDoc, deleteDoc, collection, addDoc, onSnapshot, query, where, serverTimestamp } from "./firebase.js";
import { S } from "./state.js";
import { ICE_SERVERS, AUDIO_CONSTRAINTS, VIDEO_CONSTRAINTS, VIDEO_BITRATE, AUDIO_BITRATE, MEET_MAX } from "./config.js";
import { $, $$, esc, avatar, icon, toast, openModal, closeModal, rid, beep, copyText, fmtDur, audioCtx, injectIcons } from "./utils.js";
import { sendToCurrent } from "./chat.js";
import { inCall } from "./call.js";

const roomRef = id => doc(db, "rooms", id);
const memRef = (id, uid) => doc(db, "rooms", id, "members", uid);
const sigCol = id => collection(db, "rooms", id, "signals");

let M = null; // active meeting state

export const linkFor = id => `${location.origin}${location.pathname}?meet=${id}`;

/* ---------------- create / join ---------------- */
export async function createMeeting({ title, kind = "video", chatId = null } = {}) {
  const id = rid(3) + "-" + rid(4) + "-" + rid(3);
  try {
    await setDoc(roomRef(id), { hostId: S.uid, title: title || `${S.me.displayName}'s meeting`, kind, chatId, createdAt: serverTimestamp() });
  } catch (e) {
    console.error(e);
    toast(e.code === "permission-denied" ? "Meetings need the updated Firestore rules (see README, 1 minute step)" : "Could not create meeting", "err", 6000);
    return null;
  }
  return id;
}

export async function startMeetingFromChat(kind = "video") {
  if (!S.chatId) return;
  if (inCall() || M) return toast("You are already in a call");
  const title = S.isGroup ? (S.chatDoc?.name || "Group") + " call" : `${S.me.displayName} & ${S.peer?.displayName?.split(" ")[0] || ""}`;
  const id = await createMeeting({ title, kind, chatId: S.chatId });
  if (!id) return;
  await sendToCurrent({ type: "meeting", roomId: id, title, kind });
  joinMeeting(id, { kind });
}

export async function joinMeeting(code, opts = {}) {
  code = String(code || "").trim().toLowerCase().replace(/^.*[?&]meet=/, "").replace(/\s+/g, "");
  if (!code) return toast("Enter a meeting code", "err");
  if (M || inCall()) return toast("You are already in a call");
  let room;
  try {
    const s = await getDoc(roomRef(code));
    if (!s.exists()) return toast("Meeting not found. Check the code.", "err");
    room = s.data();
  } catch (e) { return toast(e.code === "permission-denied" ? "Meetings need the updated Firestore rules (see README)" : "Could not open meeting", "err", 5000); }
  lobby(code, room, opts);
}

/* ---------------- lobby (preview) ---------------- */
async function lobby(code, room, opts) {
  let stream = null, mic = true, cam = (opts.kind || room.kind) !== "voice";
  openModal(`<div class="mc-head"><h3>${esc(room.title || "Meeting")}</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <div class="lobby">
      <video id="lbVid" autoplay playsinline muted></video>
      <div class="row"><button class="tgl" id="lbMic">${icon("mic", 16)} Mic on</button><button class="tgl" id="lbCam">${icon("video", 16)} Camera on</button></div>
      <p class="muted tiny center">Code: <b>${esc(code)}</b></p>
      <button class="btn-primary" id="lbJoin">Join now</button>
    </div>`, "wide");
  const apply = () => {
    $("#lbMic").className = "tgl" + (mic ? "" : " off"); $("#lbMic").innerHTML = icon(mic ? "mic" : "mic-off", 16) + (mic ? " Mic on" : " Mic off");
    $("#lbCam").className = "tgl" + (cam ? "" : " off"); $("#lbCam").innerHTML = icon(cam ? "video" : "video-off", 16) + (cam ? " Camera on" : " Camera off");
    $("#lbVid").style.opacity = cam ? 1 : .15;
    stream?.getAudioTracks().forEach(t => { t.enabled = mic; }); stream?.getVideoTracks().forEach(t => { t.enabled = cam; });
  };
  const close = (keep) => { if (!keep) stream?.getTracks().forEach(t => t.stop()); closeModal(); };
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: AUDIO_CONSTRAINTS, video: { ...VIDEO_CONSTRAINTS, facingMode: "user" } }); }
  catch { try { stream = await navigator.mediaDevices.getUserMedia({ audio: AUDIO_CONSTRAINTS }); cam = false; $("#lbCam").disabled = true; toast("Camera not available - joining with audio"); } catch { toast("Please allow microphone access to join", "err"); closeModal(); return; } }
  if (!$("#lbVid")) { stream.getTracks().forEach(t => t.stop()); return; }
  $("#lbVid").srcObject = stream; apply();
  $("#modalCard").onclick = e => {
    if (e.target.closest("[data-x]")) return close();
    if (e.target.closest("#lbMic")) { mic = !mic; apply(); }
    else if (e.target.closest("#lbCam") && !$("#lbCam").disabled) { if (!stream.getVideoTracks().length) return; cam = !cam; apply(); }
    else if (e.target.closest("#lbJoin")) { const st = stream; close(true); enter(code, room, st, { mic, cam }); }
  };
}

/* ---------------- enter the meeting ---------------- */
async function enter(code, room, stream, init) {
  const camTrack = stream.getVideoTracks()[0] || null, micTrack = stream.getAudioTracks()[0];
  M = {
    id: code, room, stream, camTrack, micTrack, screen: null, pcs: new Map(), members: new Map(), tiles: new Map(), streams: new Map(),
    st: { mic: init.mic, cam: init.cam && !!camTrack, screen: false, hand: false }, joined: Date.now(), unsubs: [], spot: false, pin: null, reacts: {}, timer: null, hb: null
  };
  if (micTrack) micTrack.enabled = M.st.mic; if (camTrack) camTrack.enabled = M.st.cam;
  const o = $("#meetOverlay"); o.classList.remove("hidden");
  $("#meetTitle").textContent = room.title || "Meeting"; $("#meetCode").textContent = "Code " + code;
  $("#meetGrid").innerHTML = ""; $("#meetSide").classList.add("hidden");
  M.timer = setInterval(() => { $("#meetTimer").textContent = fmtDur((Date.now() - M.joined) / 1000); }, 1000);
  paintControls();
  addTile(S.uid, true); setTileStream(S.uid, stream);
  try {
    await setDoc(memRef(code, S.uid), memberDoc());
  } catch (e) { console.error(e); toast("Could not join the meeting", "err"); return leave(true); }
  M.hb = setInterval(() => updateDoc(memRef(code, S.uid), { ts: Date.now() }).catch(() => {}), 20000);
  M.unsubs.push(onSnapshot(collection(db, "rooms", code, "members"), snap => onMembers(snap)));
  M.unsubs.push(onSnapshot(query(sigCol(code), where("to", "==", S.uid)), snap => snap.docChanges().forEach(c => { if (c.type === "added") onSignal(c.doc); })));
  beep("join");
}
const memberDoc = () => ({ uid: S.uid, name: S.me.displayName, photo: S.me.photoURL || "", j: M.joined, ts: Date.now(), ...M.st, react: null });
const pushState = () => updateDoc(memRef(M.id, S.uid), { ...M.st, ts: Date.now() }).catch(() => {});

/* ---------------- members ---------------- */
function onMembers(snap) {
  if (!M) return;
  const now = Date.now(), live = new Map();
  snap.forEach(d => { const m = d.data(); if (m.uid === S.uid || now - (m.ts || 0) < 75000) live.set(m.uid, m); });
  // left
  for (const uid of [...M.members.keys()]) if (!live.has(uid)) { dropPeer(uid); M.members.delete(uid); removeTile(uid); beep("leave"); }
  // joined / changed
  live.forEach((m, uid) => {
    if (uid === S.uid) return;
    const prev = M.members.get(uid); M.members.set(uid, m);
    if (!prev) {
      if (live.size > MEET_MAX) { if (M.members.size >= MEET_MAX) return; }
      addTile(uid, false); beep("join");
      // newer joiner initiates (deterministic for both sides)
      if (m.j < M.joined || (m.j === M.joined && uid < S.uid)) makePeer(uid, true);
    } else {
      if (m.react && m.react.t !== prev.react?.t && Date.now() - m.react.t < 5000) floatReact(m.react.e, m.name);
      if (m.hand && !prev.hand) toast(`✋ ${m.name} raised a hand`);
    }
    paintTile(uid);
  });
  paintTile(S.uid); layoutGrid(); paintSide();
}

/* ---------------- WebRTC mesh ---------------- */
function makePeer(uid, initiator) {
  if (M.pcs.has(uid)) return M.pcs.get(uid);
  const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS, iceCandidatePoolSize: 2, bundlePolicy: "max-bundle" });
  const peer = { pc, uid, initiator, pending: [], restarts: 0, stream: new MediaStream() };
  M.pcs.set(uid, peer);
  if (M.micTrack) pc.addTrack(M.micTrack, M.stream); else pc.addTransceiver("audio", { direction: "sendrecv" });
  const vt = currentVideoTrack();
  if (vt) pc.addTrack(vt, M.stream); else pc.addTransceiver("video", { direction: "sendrecv" });
  pc.ontrack = e => {
    peer.stream.addTrack(e.track);
    e.track.onunmute = () => paintTile(uid);
    setTileStream(uid, peer.stream);
  };
  pc.onicecandidate = e => { if (e.candidate) sendSig(uid, "ice", e.candidate.toJSON()); };
  pc.onconnectionstatechange = () => {
    paintTile(uid);
    if (pc.connectionState === "connected") { tuneSenders(pc); }
    if (pc.connectionState === "failed" && peer.initiator && peer.restarts++ < 3) negotiate(peer, true);
    if (pc.connectionState === "disconnected" && peer.initiator) setTimeout(() => { if (M?.pcs.get(uid) === peer && pc.connectionState !== "connected" && peer.restarts++ < 3) negotiate(peer, true); }, 4000);
  };
  if (initiator) negotiate(peer, false);
  return peer;
}
async function negotiate(peer, iceRestart) {
  try {
    const offer = await peer.pc.createOffer(iceRestart ? { iceRestart: true } : undefined);
    await peer.pc.setLocalDescription(offer);
    sendSig(peer.uid, "offer", { type: offer.type, sdp: offer.sdp });
  } catch (e) { console.warn("negotiate", e); }
}
function sendSig(to, kind, data) {
  if (!M) return;
  addDoc(sigCol(M.id), { from: S.uid, to, kind, data: JSON.stringify(data), t: Date.now() }).catch(() => {});
}
async function onSignal(d) {
  const s = d.data(); deleteDoc(d.ref).catch(() => {});
  if (!M || Date.now() - (s.t || 0) > 60000) return;
  const data = JSON.parse(s.data);
  let peer = M.pcs.get(s.from);
  try {
    if (s.kind === "offer") {
      if (!peer) peer = makePeer(s.from, false);
      const pc = peer.pc;
      await pc.setRemoteDescription(data);
      // attach our tracks to the transceivers the remote offer created
      for (const t of pc.getTransceivers()) {
        t.direction = "sendrecv";
        const track = t.receiver.track.kind === "audio" ? M.micTrack : currentVideoTrack();
        if (track && t.sender.track !== track) await t.sender.replaceTrack(track).catch(() => {});
      }
      const ans = await pc.createAnswer(); await pc.setLocalDescription(ans);
      sendSig(s.from, "answer", { type: ans.type, sdp: ans.sdp });
      peer.pending.splice(0).forEach(c => pc.addIceCandidate(c).catch(() => {}));
    } else if (s.kind === "answer" && peer) {
      await peer.pc.setRemoteDescription(data);
      peer.pending.splice(0).forEach(c => peer.pc.addIceCandidate(c).catch(() => {}));
    } else if (s.kind === "ice") {
      if (!peer) peer = makePeer(s.from, false);
      if (peer.pc.remoteDescription) peer.pc.addIceCandidate(data).catch(() => {}); else peer.pending.push(data);
    }
  } catch (e) { console.warn("signal", s.kind, e); }
}
function dropPeer(uid) {
  const p = M.pcs.get(uid); if (!p) return;
  try { p.pc.close(); } catch { /* ignore */ }
  M.pcs.delete(uid); M.streams.delete(uid);
}
async function tuneSenders(pc) {
  const n = Math.max(1, M.pcs.size);
  for (const s of pc.getSenders()) {
    if (!s.track) continue;
    try {
      const p = s.getParameters(); if (!p.encodings?.length) p.encodings = [{}];
      if (s.track.kind === "audio") p.encodings[0].maxBitrate = AUDIO_BITRATE;
      else { p.encodings[0].maxBitrate = n <= 2 ? VIDEO_BITRATE.hd : n <= 4 ? 900_000 : 450_000; p.encodings[0].maxFramerate = n <= 4 ? 30 : 20; if (n > 4) p.encodings[0].scaleResolutionDownBy = 1.5; }
      await s.setParameters(p);
    } catch { /* ignore */ }
  }
}
const currentVideoTrack = () => (M.screen ? M.screen.getVideoTracks()[0] : (M.st.cam ? M.camTrack : null));
async function swapVideo() {
  const t = currentVideoTrack();
  for (const { pc } of M.pcs.values()) {
    const s = pc.getTransceivers().find(x => x.receiver.track.kind === "video")?.sender;
    if (s) await s.replaceTrack(t).catch(() => {});
  }
  const local = new MediaStream([M.micTrack, ...(t ? [t] : [])].filter(Boolean));
  M.stream = local; setTileStream(S.uid, local);
}

/* ---------------- tiles / grid ---------------- */
function addTile(uid, self) {
  if (M.tiles.has(uid)) return;
  const el = document.createElement("div");
  el.className = "tile" + (self ? " self" : ""); el.dataset.uid = uid;
  el.innerHTML = `<video autoplay playsinline ${self ? "muted" : ""}></video><div class="t-av"></div><div class="t-flags"></div><div class="t-state"></div><div class="t-name"><span></span></div>`;
  el.onclick = () => { M.pin = M.pin === uid ? null : uid; M.spot = !!M.pin || M.spot; layoutGrid(); };
  $("#meetGrid").appendChild(el); M.tiles.set(uid, el);
  paintTile(uid); layoutGrid();
}
function removeTile(uid) { M.tiles.get(uid)?.remove(); M.tiles.delete(uid); if (M.pin === uid) M.pin = null; layoutGrid(); }
function setTileStream(uid, stream) {
  M.streams.set(uid, stream);
  const el = M.tiles.get(uid); if (!el) return;
  const v = el.querySelector("video"); if (v.srcObject !== stream) { v.srcObject = stream; v.play?.().catch(() => {}); }
  watchSpeaker(uid, stream);
}
function paintTile(uid) {
  const el = M.tiles.get(uid); if (!el) return;
  const self = uid === S.uid, m = self ? { ...M.st, name: S.me.displayName, photo: S.me.photoURL } : M.members.get(uid);
  if (!m) return;
  const showVid = !!(m.cam || m.screen);
  el.classList.toggle("has-video", showVid); el.classList.toggle("screen", !!m.screen);
  el.querySelector(".t-av").innerHTML = avatar({ displayName: m.name, photoURL: m.photo }, 84);
  el.querySelector(".t-name span").textContent = (self ? "You" : m.name) + (m.screen ? " (screen)" : "");
  el.querySelector(".t-flags").innerHTML = (m.hand ? '<span class="t-flag">✋</span>' : "") + (!m.mic ? `<span class="t-flag red">${icon("mic-off", 14)}</span>` : "");
  const p = M.pcs.get(uid), st = el.querySelector(".t-state");
  st.textContent = !self && p && ["connecting", "new"].includes(p.pc.connectionState) ? "Connecting..." : !self && p && ["disconnected", "failed"].includes(p.pc.connectionState) ? "Reconnecting..." : "";
}
function layoutGrid() {
  if (!M) return;
  const g = $("#meetGrid"), n = M.tiles.size, wide = innerWidth > 860;
  const cols = n <= 1 ? 1 : n === 2 ? (wide ? 2 : 1) : n <= 4 ? 2 : n <= 6 ? (wide ? 3 : 2) : 3;
  g.style.gridTemplateColumns = `repeat(${cols},minmax(0,1fr))`;
  const main = M.pin || [...M.tiles.keys()].find(u => (u === S.uid ? M.st.screen : M.members.get(u)?.screen)) || null;
  g.classList.toggle("spot", !!(M.spot && main));
  M.tiles.forEach((el, u) => el.classList.toggle("main", u === main));
  if (M.spot && main) g.style.gridTemplateColumns = "1fr";
}
function paintSide() {
  const s = $("#meetSide"); if (s.classList.contains("hidden")) return;
  const rows = [[S.uid, { ...M.st, name: S.me.displayName + " (You)", photo: S.me.photoURL }], ...M.members.entries()];
  s.innerHTML = `<header><span>People (${rows.length})</span><button class="icon-btn small" data-close>${icon("x", 16)}</button></header><div class="ms-body">${rows.map(([u, m]) => `<div class="ms-row">${avatar({ displayName: m.name, photoURL: m.photo }, 34)}<span class="n">${esc(m.name)}</span><span class="st">${m.hand ? "✋" : ""}${icon(m.mic ? "mic" : "mic-off", 16)}${icon(m.cam || m.screen ? "video" : "video-off", 16)}</span></div>`).join("")}</div>`;
}
// speaking indicator
const analysers = new Map();
function watchSpeaker(uid, stream) {
  const old = analysers.get(uid); if (old?.sid === stream.id && old.n === stream.getAudioTracks().length) return;
  if (old) { cancelAnimationFrame(old.raf); try { old.src.disconnect(); } catch { /* ignore */ } }
  if (!stream.getAudioTracks().length) return;
  try {
    const ctx = audioCtx(); if (!ctx) return;
    const src = ctx.createMediaStreamSource(new MediaStream([stream.getAudioTracks()[0]])), an = ctx.createAnalyser(); an.fftSize = 256; src.connect(an);
    const buf = new Uint8Array(an.frequencyBinCount), a = { sid: stream.id, n: stream.getAudioTracks().length, src, raf: 0 };
    const tick = () => {
      a.raf = requestAnimationFrame(tick); if (!M) return;
      an.getByteFrequencyData(buf); let s = 0; for (let i = 0; i < 40; i++) s += buf[i];
      const el = M.tiles.get(uid); if (el) el.classList.toggle("speaking", s / 40 > 38 && (uid !== S.uid || M.st.mic));
    };
    analysers.set(uid, a); tick();
  } catch { /* ignore */ }
}

/* ---------------- controls ---------------- */
function paintControls() {
  const b = (id, ic, on, offIc) => { const e = $(id); e.innerHTML = icon(on ? ic : (offIc || ic), 22); };
  b("#mMute", "mic", M.st.mic, "mic-off"); $("#mMute").classList.toggle("off", !M.st.mic);
  b("#mCam", "video", M.st.cam, "video-off"); $("#mCam").classList.toggle("off", !M.st.cam);
  $("#mShare").classList.toggle("on", M.st.screen); $("#mHand").classList.toggle("on", M.st.hand);
}
async function toggleCam() {
  if (!M.camTrack) { try { const ns = await navigator.mediaDevices.getUserMedia({ video: VIDEO_CONSTRAINTS }); M.camTrack = ns.getVideoTracks()[0]; } catch { return toast("Camera not available", "err"); } }
  M.st.cam = !M.st.cam; M.camTrack.enabled = true;
  if (!M.st.cam && !M.screen) { /* keep track alive but detach */ }
  await swapVideo(); paintControls(); paintTile(S.uid); pushState();
}
async function toggleShare() {
  if (M.screen) return stopScreen();
  if (!navigator.mediaDevices?.getDisplayMedia) return toast("Screen sharing is not supported on this device", "err");
  try {
    M.screen = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 15 }, audio: false });
    M.screen.getVideoTracks()[0].onended = stopScreen;
    M.st.screen = true; await swapVideo(); paintControls(); paintTile(S.uid); layoutGrid(); pushState();
  } catch { M.screen = null; }
}
async function stopScreen() {
  if (!M?.screen) return;
  M.screen.getTracks().forEach(t => t.stop()); M.screen = null; M.st.screen = false;
  await swapVideo(); paintControls(); paintTile(S.uid); layoutGrid(); pushState();
}
function floatReact(e, name) {
  const el = document.createElement("div"); el.className = "float-react"; el.style.left = (15 + Math.random() * 70) + "%";
  el.innerHTML = `${e}<small>${esc(name || "")}</small>`; $("#meetReacts").appendChild(el); setTimeout(() => el.remove(), 2700);
}

export async function leave(silent) {
  if (!M) return;
  const m = M; M = null;
  clearInterval(m.timer); clearInterval(m.hb); m.unsubs.forEach(u => u());
  analysers.forEach(a => { cancelAnimationFrame(a.raf); try { a.src.disconnect(); } catch { /* ignore */ } }); analysers.clear();
  m.pcs.forEach(p => { try { p.pc.close(); } catch { /* ignore */ } });
  m.stream?.getTracks().forEach(t => t.stop()); m.camTrack?.stop(); m.micTrack?.stop(); m.screen?.getTracks().forEach(t => t.stop());
  $("#meetOverlay").classList.add("hidden"); $("#meetGrid").innerHTML = ""; $("#meetEmoji").classList.add("hidden");
  deleteDoc(memRef(m.id, S.uid)).catch(() => {});
  if (!silent) beep("leave");
}

export function initMeetUI() {
  $("#mMute").onclick = () => { if (!M.micTrack) return; M.st.mic = !M.st.mic; M.micTrack.enabled = M.st.mic; paintControls(); paintTile(S.uid); pushState(); };
  $("#mCam").onclick = toggleCam;
  $("#mShare").onclick = toggleShare;
  $("#mHand").onclick = () => { M.st.hand = !M.st.hand; paintControls(); paintTile(S.uid); pushState(); };
  const em = $("#meetEmoji"); em.innerHTML = ["👍", "❤️", "😂", "😮", "👏", "🎉", "🙏", "🔥"].map(e => `<button data-e="${e}">${e}</button>`).join("");
  $("#mReact").onclick = ev => { ev.stopPropagation(); em.classList.toggle("hidden"); };
  em.onclick = ev => { const b = ev.target.closest("[data-e]"); if (!b) return; em.classList.add("hidden"); floatReact(b.dataset.e, "You"); updateDoc(memRef(M.id, S.uid), { react: { e: b.dataset.e, t: Date.now() } }).catch(() => {}); };
  $("#mLayout").onclick = () => { M.spot = !M.spot; layoutGrid(); toast(M.spot ? "Spotlight view (tap a tile to pin)" : "Grid view"); };
  $("#mLeave").onclick = () => leave();
  $("#meetPeopleBtn").onclick = () => { $("#meetSide").classList.toggle("hidden"); paintSide(); };
  $("#meetSide").onclick = e => { if (e.target.closest("[data-close]")) $("#meetSide").classList.add("hidden"); };
  $("#meetInvite").onclick = async () => {
    const link = linkFor(M.id), text = `Join my Kotha meeting: ${M.room.title || ""}\n${link}\nCode: ${M.id}`;
    if (navigator.share) { try { await navigator.share({ title: "Kotha meeting", text, url: link }); return; } catch { /* cancelled */ } }
    toast(await copyText(text) ? "Invite link copied" : "Copy failed", "ok");
  };
  document.addEventListener("click", e => { if (!e.target.closest("#meetEmoji") && !e.target.closest("#mReact")) $("#meetEmoji").classList.add("hidden"); });
  window.addEventListener("pagehide", () => { if (M) deleteDoc(memRef(M.id, S.uid)).catch(() => {}); });
  window.addEventListener("resize", () => M && layoutGrid());
  initMeetHome();
}

/* ---------------- Meet tab ---------------- */
function initMeetHome() {
  $("#meetHome").innerHTML = `
    <div class="meet-hero"><h3>Meet with anyone</h3><p>HD video meetings for up to ${MEET_MAX} people. Share your screen, raise hands and react live.</p>
      <button class="btn-light" id="mhNew">${icon("video", 18)} New meeting</button></div>
    <div class="join-row"><input id="mhCode" placeholder="Enter meeting code or link" autocomplete="off" autocapitalize="off"><button class="btn-primary" id="mhJoin" style="padding:0 20px">Join</button></div>
    <div class="feat-grid">
      <div class="feat"><i>${icon("users", 18)}</i><b>Group calls</b>Start from any group chat with one tap</div>
      <div class="feat"><i>${icon("monitor", 18)}</i><b>Screen share</b>Present your screen to everyone</div>
      <div class="feat"><i>${icon("hand", 18)}</i><b>Raise hand</b>Let others know you want to speak</div>
      <div class="feat"><i>${icon("link", 18)}</i><b>Invite link</b>Share a link, no app install needed</div>
    </div>`;
  $("#meetHome").addEventListener("click", async e => {
    if (e.target.closest("#mhNew")) { const id = await createMeeting({}); if (id) joinMeeting(id); }
    else if (e.target.closest("#mhJoin")) joinMeeting($("#mhCode").value);
  });
  $("#meetHome").addEventListener("keydown", e => { if (e.key === "Enter" && e.target.id === "mhCode") joinMeeting(e.target.value); });
}
export const inMeeting = () => !!M;
