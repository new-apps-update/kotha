import { db, doc, updateDoc, onSnapshot, serverTimestamp } from "./firebase.js";
import { S } from "./state.js";
import { initAuth } from "./auth.js";
import * as chat from "./chat.js";
import * as call from "./call.js";
import * as meet from "./meet.js";
import { initPeople, loadDiscover } from "./people.js";
import { initSettings, renderSettings } from "./settings.js";
import { applyPrefs, setPref, prefs, effectiveTheme } from "./prefs.js";
import { $, $$, avatar, injectIcons, injectLogos, toast } from "./utils.js";

applyPrefs();
injectLogos();
injectIcons();
applyPrefs();

const splashStart = Date.now();
let splashGone = false;
const hideSplash = () => {
  if (splashGone) return; splashGone = true;
  const wait = Math.max(0, 2300 - (Date.now() - splashStart));
  setTimeout(() => { $("#splash").classList.add("out"); setTimeout(() => $("#splash").remove(), 600); }, wait);
};

/* ---------- navigation ---------- */
let nav = "chats";
const panels = { chats: "#pChats", people: "#pPeople", meet: "#pMeet", me: "#pMe" };
function setNav(n) {
  nav = n;
  Object.entries(panels).forEach(([k, s]) => $(s).classList.toggle("hidden", k !== n));
  $$("[data-nav]").forEach(b => b.classList.toggle("active", b.dataset.nav === n));
  if (n === "people") loadDiscover();
  if (n === "me") renderSettings();
  if (S.chatId && n !== "chats" && matchMedia("(max-width:860px)").matches) chat.goBack();
}

/* ---------- presence ---------- */
let presenceTimer = null, meUnsub = null;
function startPresence() {
  const ref = doc(db, "users", S.uid);
  const ping = online => updateDoc(ref, { online, lastSeen: serverTimestamp() }).catch(() => {});
  ping(true);
  clearInterval(presenceTimer);
  presenceTimer = setInterval(() => { if (document.visibilityState === "visible") ping(true); }, 30000);
  document.addEventListener("visibilitychange", () => ping(document.visibilityState === "visible"));
  window.addEventListener("pagehide", () => ping(false));
}

/* ---------- boot ---------- */
let uiReady = false, started = false;
function initUI() {
  if (uiReady) return; uiReady = true;
  chat.initChatUI(); call.initCallUI(); meet.initMeetUI(); initPeople(); initSettings();
  $("#themeBtn").onclick = () => setPref("theme", effectiveTheme() === "dark" ? "light" : "dark");
  $("#meBtn").onclick = () => setNav("me");
  $("#railLogo").onclick = () => setNav("chats");
  $("#newChatBtn").onclick = () => { setNav("people"); };
  $$("[data-nav]").forEach(b => b.addEventListener("click", () => setNav(b.dataset.nav)));
  window.addEventListener("popstate", () => { if (!history.state?.chat && S.chatId) chat.closeChat(); });
  const off = () => $("#offlineBar").classList.toggle("hidden", navigator.onLine);
  window.addEventListener("online", off); window.addEventListener("offline", off); off();
}

initAuth({
  onReady: (user, data) => {
    S.user = user; S.uid = user.uid; S.me = { id: user.uid, ...data };
    $("#app").classList.remove("hidden");
    initUI();
    $("#meBtn").innerHTML = avatar(S.me, 40);
    if (!started) {
      started = true;
      meUnsub?.();
      meUnsub = onSnapshot(doc(db, "users", S.uid), s => {
        if (!s.exists()) return;
        S.me = { id: s.id, ...s.data() };
        $("#meBtn").innerHTML = avatar(S.me, 40);
        chat.refreshMe(); renderSettings();
      });
      startPresence();
      chat.startChatList();
      call.listenIncoming();
      setNav("chats");
      // open an invite link:  ?meet=CODE
      const code = new URLSearchParams(location.search).get("meet");
      if (code) { history.replaceState({}, "", location.pathname); setTimeout(() => meet.joinMeeting(code), 2600); }
    }
    hideSplash();
  },
  onLoggedOut: () => {
    if (started) {
      chat.closeChat(); chat.stopChatList(); call.stopIncoming(); meUnsub?.(); meUnsub = null; meet.leave(true);
      clearInterval(presenceTimer);
      started = false; S.uid = null; S.me = null; S.chatItems = []; S.knownChats.clear();
      $("#app").classList.add("hidden");
      $("#chatList").innerHTML = ""; $("#discoverList").innerHTML = "";
    }
    hideSplash();
  }
});

window.addEventListener("error", e => console.error(e.error || e.message));
window.addEventListener("unhandledrejection", e => console.warn("unhandled", e.reason));

/* ---------- PWA ---------- */
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
}
