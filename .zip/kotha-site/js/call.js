import { db, doc, setDoc, getDoc, updateDoc, collection, addDoc, onSnapshot, query, where, serverTimestamp } from "./firebase.js";
import { S } from "./state.js";
import { ICE_SERVERS, AUDIO_CONSTRAINTS, VIDEO_CONSTRAINTS, VIDEO_BITRATE, AUDIO_BITRATE } from "./config.js";
import { $, avatar, icon, toast, tone } from "./utils.js";
import { sendToPeer, getUser } from "./chat.js";
import { notify } from "./prefs.js";

let pc = null, local = null, camTrack = null, screenStream = null, callId = null, role = null, ended = true, peerInfo = null, currentType = "voice";
let unsubs = [], pending = [], outQueue = [], ready = false, facing = "user";
let connectedAt = 0, timerI = null, ringI = null, ringTimeout = null, statsI = null, restartT = null, rv = 0, lastRv = 0, quality = "hd", wakeLock = null;
let incomingId = null, incomingData = null, incomingUnsub = null, prevIn = null;

const callRef = () => doc(db, "calls", callId);

/* ---------------- ring tones ---------------- */
function startRing(kind) {
  stopRing();
  const play = () => kind === "in"
    ? (tone(740, 0, .25, .12), tone(988, .28, .25, .12), tone(740, .8, .25, .12), tone(988, 1.08, .25, .12))
    : (tone(440, 0, .9, .06), tone(480, 0, .9, .06));
  play(); ringI = setInterval(play, kind === "in" ? 2600 : 3000);
}
function stopRing() { clearInterval(ringI); ringI = null; }

/* ---------------- UI ---------------- */
function showCallUI(peer, type, status) {
  const o = $("#callOverlay");
  o.classList.remove("hidden", "connected", "remote-video", "local-video", "screen-local", "screen-remote");
  o.classList.toggle("video-call", type === "video");
  $("#callAvatar").innerHTML = avatar(peer, 120);
  $("#callName").textContent = peer.displayName;
  $("#callNote").textContent = "";
  $("#callQuality").dataset.q = "0";
  setStatus(status);
  ["#muteBtn", "#camBtn", "#shareBtn"].forEach(s => $(s).classList.remove("off", "on"));
  $("#muteBtn").innerHTML = icon("mic", 24); $("#camBtn").innerHTML = icon("video", 24);
  if (type === "video") o.classList.add("local-video");
}
const setStatus = t => { $("#callStatus").textContent = t; };
function hideCallUI() { $("#callOverlay").classList.add("hidden"); $("#remoteVideo").srcObject = null; $("#localVideo").srcObject = null; }

function onConnected() {
  if (connectedAt) return;
  connectedAt = Date.now(); stopRing(); clearTimeout(ringTimeout);
  $("#callOverlay").classList.add("connected");
  if (currentType === "video") $("#callOverlay").classList.add("remote-video");
  timerI = setInterval(() => {
    const s = Math.floor((Date.now() - connectedAt) / 1000);
    setStatus(`${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`);
  }, 500);
  setStatus("00:00");
  applyBitrates(); startStats();
  try { navigator.wakeLock?.request("screen").then(w => { wakeLock = w; }).catch(() => {}); } catch { /* ignore */ }
}

/* ---------------- quality tuning ---------------- */
// Opus: forward error correction + DTX + fixed mono bitrate = clear voice even on bad networks
function tuneSdp(sdp) {
  try {
    const m = sdp.match(/a=rtpmap:(\d+) opus\/48000\/2/); if (!m) return sdp;
    const pt = m[1];
    return sdp.replace(new RegExp(`a=fmtp:${pt} ([^\\r\\n]*)`), (all, p) => {
      const add = { useinbandfec: 1, usedtx: 1, stereo: 0, "sprop-stereo": 0, maxaveragebitrate: AUDIO_BITRATE, maxplaybackrate: 48000 };
      let out = p; Object.entries(add).forEach(([k, v]) => { out = new RegExp(`(^|;)${k}=`).test(out) ? out.replace(new RegExp(`${k}=[^;]*`), `${k}=${v}`) : out + `;${k}=${v}`; });
      return `a=fmtp:${pt} ${out}`;
    });
  } catch { return sdp; }
}
const munge = d => ({ type: d.type, sdp: tuneSdp(d.sdp) });
async function setLocal(desc) {
  try { await pc.setLocalDescription(munge(desc)); } catch { await pc.setLocalDescription(desc); }
  return pc.localDescription;
}
async function applyBitrates() {
  if (!pc) return;
  for (const s of pc.getSenders()) {
    if (!s.track) continue;
    try {
      const p = s.getParameters(); if (!p.encodings?.length) p.encodings = [{}];
      if (s.track.kind === "audio") { p.encodings[0].maxBitrate = AUDIO_BITRATE; p.encodings[0].priority = "high"; p.encodings[0].networkPriority = "high"; }
      else {
        p.encodings[0].maxBitrate = VIDEO_BITRATE[quality]; p.encodings[0].maxFramerate = quality === "low" ? 15 : 30;
        p.encodings[0].scaleResolutionDownBy = quality === "low" ? 2 : quality === "sd" ? 1.5 : 1;
        p.degradationPreference = screenStream ? "maintain-resolution" : "balanced";
      }
      await s.setParameters(p);
    } catch { /* not supported */ }
  }
}
let lastIn = null;
function startStats() {
  clearInterval(statsI);
  statsI = setInterval(async () => {
    if (!pc) return;
    try {
      const st = await pc.getStats(); let rtt = 0, recv = 0, lost = 0, jitter = 0;
      st.forEach(r => {
        if (r.type === "candidate-pair" && r.state === "succeeded" && r.nominated) rtt = (r.currentRoundTripTime || 0) * 1000;
        if (r.type === "inbound-rtp") { recv += r.packetsReceived || 0; lost += r.packetsLost || 0; jitter = Math.max(jitter, (r.jitter || 0) * 1000); }
      });
      let lossPct = 0;
      if (lastIn) { const dr = recv - lastIn.recv, dl = lost - lastIn.lost; lossPct = dr + dl > 0 ? Math.max(0, dl) / (dr + dl) * 100 : 0; }
      lastIn = { recv, lost };
      const score = rtt > 600 || lossPct > 15 ? 1 : rtt > 350 || lossPct > 7 ? 2 : rtt > 180 || lossPct > 2 ? 3 : 4;
      $("#callQuality").dataset.q = score;
      $("#callNote").textContent = score <= 1 ? "Weak connection - lowering quality" : score === 2 ? "Unstable connection" : "";
      const want = score <= 1 ? "low" : score === 2 ? "sd" : "hd";
      if (want !== quality && currentType === "video") { quality = want; applyBitrates(); }
    } catch { /* ignore */ }
  }, 3000);
}

/* ---------------- peer connection ---------------- */
function makePC() {
  pc = new RTCPeerConnection({ iceServers: ICE_SERVERS, iceCandidatePoolSize: 4, bundlePolicy: "max-bundle", rtcpMuxPolicy: "require" });
  local.getTracks().forEach(t => { const s = pc.addTrack(t, local); if (t.kind === "video") try { t.contentHint = "motion"; } catch { /* ignore */ } return s; });
  $("#localVideo").srcObject = local;
  pc.ontrack = e => { const rv_ = $("#remoteVideo"); rv_.srcObject = e.streams[0] || new MediaStream([e.track]); rv_.play?.().catch(() => {}); };
  pc.onicecandidate = e => {
    if (!e.candidate) return;
    const c = e.candidate.toJSON();
    if (ready) addDoc(collection(callRef(), "candidates"), { from: S.uid, candidate: c }).catch(() => {});
    else outQueue.push(c);
  };
  pc.onconnectionstatechange = () => {
    if (!pc) return;
    const st = pc.connectionState;
    if (st === "connected") { clearTimeout(restartT); $("#callNote").textContent = ""; onConnected(); }
    else if (st === "disconnected") { $("#callNote").textContent = "Reconnecting..."; clearTimeout(restartT); restartT = setTimeout(() => restartIce(), 3500); }
    else if (st === "failed") { $("#callNote").textContent = "Reconnecting..."; restartIce(true); }
  };
}
let restarts = 0;
async function restartIce(fromFail) {
  if (!pc || ended) return;
  if (role !== "caller") { clearTimeout(restartT); restartT = setTimeout(() => { if (pc && pc.connectionState !== "connected" && !ended) { toast("Call connection failed", "err"); endCall("failed"); } }, 15000); return; }
  if (++restarts > 4) { toast("Call connection failed", "err"); return endCall("failed"); }
  try {
    const offer = await pc.createOffer({ iceRestart: true });
    const d = await setLocal(offer);
    rv++; await updateDoc(callRef(), { offer: { type: d.type, sdp: d.sdp }, rv });
    restartT = setTimeout(() => { if (pc && pc.connectionState !== "connected") restartIce(); }, 9000);
  } catch (e) { console.warn("ice restart", e); }
}
function flushOut() {
  ready = true;
  outQueue.splice(0).forEach(c => addDoc(collection(callRef(), "candidates"), { from: S.uid, candidate: c }).catch(() => {}));
}
function addCand(c) {
  if (pc?.remoteDescription) pc.addIceCandidate(c).catch(() => {});
  else pending.push(c);
}
const drainPending = () => pending.splice(0).forEach(c => pc?.addIceCandidate(c).catch(() => {}));
function watchCandidates() {
  unsubs.push(onSnapshot(collection(callRef(), "candidates"), s =>
    s.docChanges().forEach(c => { if (c.type === "added" && c.doc.data().from !== S.uid) addCand(c.doc.data().candidate); })));
}
async function getMedia(type) {
  if (!window.RTCPeerConnection || !navigator.mediaDevices?.getUserMedia) throw new Error("Calls are not supported on this browser");
  const tries = type === "video"
    ? [{ audio: AUDIO_CONSTRAINTS, video: { ...VIDEO_CONSTRAINTS, facingMode: "user" } }, { audio: AUDIO_CONSTRAINTS, video: { facingMode: "user" } }, { audio: true, video: true }]
    : [{ audio: AUDIO_CONSTRAINTS }, { audio: true }];
  let err;
  for (const c of tries) { try { return await navigator.mediaDevices.getUserMedia(c); } catch (e) { err = e; if (e.name === "NotAllowedError" || e.name === "NotFoundError") break; } }
  throw new Error(err?.name === "NotFoundError" ? "No microphone/camera found" : type === "video" ? "Please allow camera and microphone access" : "Please allow microphone access");
}

/* ---------------- caller ---------------- */
export async function startCall(peer, type) {
  if (pc || !ended) return toast("You are already in a call");
  if (S.me.blocked?.includes(peer.id) || peer.blocked?.includes(S.uid)) return toast("Call not available", "err");
  try { local = await getMedia(type); } catch (e) { return toast(e.message, "err"); }
  camTrack = local.getVideoTracks()[0] || null; screenStream = null; restarts = 0; rv = 0; lastRv = 0; lastIn = null; quality = "hd"; facing = "user";
  ended = false; role = "caller"; currentType = type; peerInfo = peer; connectedAt = 0; ready = false; pending = []; outQueue = [];
  callId = doc(collection(db, "calls")).id;
  showCallUI(peer, type, "Calling...");
  makePC();
  try {
    const offer = await pc.createOffer();
    const d = await setLocal(offer);
    await setDoc(callRef(), {
      callerId: S.uid, calleeId: peer.id, callerName: S.me.displayName, callerPhoto: S.me.photoURL || "",
      type, status: "ringing", offer: { type: d.type, sdp: d.sdp }, createdAt: serverTimestamp()
    });
  } catch (e) { console.error(e); toast("Could not start the call", "err"); return finish("failed"); }
  flushOut();
  unsubs.push(onSnapshot(callRef(), s => {
    const d = s.data(); if (!d || ended) return;
    if (d.answer && !pc.currentRemoteDescription) {
      stopRing(); setStatus("Connecting...");
      pc.setRemoteDescription(d.answer).then(drainPending).catch(console.error);
    } else if (d.answer && d.av && d.av === rv && d.av > lastRv) {
      lastRv = d.av; pc.setRemoteDescription(d.answer).catch(console.error);
    }
    if (d.status === "declined") { toast(`${peer.displayName} declined the call`); finish("declined"); }
    else if (d.status === "ended") finish("ended");
  }));
  watchCandidates();
  startRing("out"); setStatus("Ringing...");
  ringTimeout = setTimeout(() => { if (!connectedAt) { toast("No answer"); endCall("missed"); } }, 45000);
}

/* ---------------- callee ---------------- */
export function listenIncoming() {
  stopIncoming();
  const q = query(collection(db, "calls"), where("calleeId", "==", S.uid), where("status", "==", "ringing"));
  incomingUnsub = onSnapshot(q, snap => {
    snap.docChanges().forEach(ch => {
      if (ch.type === "added") {
        const d = ch.doc.data();
        const t = d.createdAt?.toMillis?.() ?? Date.now();
        if (Date.now() - t > 50000) return;
        if (S.me.blocked?.includes(d.callerId)) { updateDoc(ch.doc.ref, { status: "declined" }).catch(() => {}); return; }
        if (!ended || incomingId) { updateDoc(ch.doc.ref, { status: "declined" }).catch(() => {}); return; }
        showIncoming(ch.doc.id, d);
      } else if (ch.type === "removed" && incomingId === ch.doc.id) hideIncoming();
    });
  }, e => console.warn("incoming calls", e));
}
export function stopIncoming() { incomingUnsub?.(); incomingUnsub = null; hideIncoming(); }

function showIncoming(id, d) {
  incomingId = id; incomingData = d;
  $("#incAvatar").innerHTML = avatar({ displayName: d.callerName, photoURL: d.callerPhoto }, 52);
  $("#incName").textContent = d.callerName || "Someone";
  $("#incType").textContent = d.type === "video" ? "Incoming video call..." : "Incoming voice call...";
  $("#incoming").classList.remove("hidden");
  startRing("in");
  notify(d.callerName || "Incoming call", d.type === "video" ? "Incoming video call" : "Incoming voice call", { icon: d.callerPhoto, tag: "call", silent: false });
  clearTimeout(showIncoming.t); showIncoming.t = setTimeout(() => { if (incomingId === id) hideIncoming(); }, 45000);
}
function hideIncoming() {
  $("#incoming").classList.add("hidden");
  if (ended) stopRing();
  incomingId = null; incomingData = null;
}

async function acceptCall() {
  if (!incomingId) return;
  const id = incomingId, d = incomingData;
  stopRing(); $("#incoming").classList.add("hidden"); incomingId = null; incomingData = null;
  try { local = await getMedia(d.type); }
  catch (e) { toast(e.message, "err"); updateDoc(doc(db, "calls", id), { status: "declined" }).catch(() => {}); return; }
  camTrack = local.getVideoTracks()[0] || null; screenStream = null; restarts = 0; lastRv = 0; lastIn = null; quality = "hd"; facing = "user";
  callId = id; role = "callee"; ended = false; currentType = d.type; connectedAt = 0; ready = true; pending = []; outQueue = [];
  peerInfo = (await getUser(d.callerId, 60000)) || { id: d.callerId, displayName: d.callerName, photoURL: d.callerPhoto };
  showCallUI(peerInfo, d.type, "Connecting...");
  makePC();
  try {
    const snap = await getDoc(callRef());
    if (!snap.exists() || snap.data().status !== "ringing") { toast("Call already ended"); return finish("ended"); }
    await pc.setRemoteDescription(d.offer);
    const ans = await pc.createAnswer();
    const ld = await setLocal(ans);
    await updateDoc(callRef(), { answer: { type: ld.type, sdp: ld.sdp }, status: "accepted" });
  } catch (e) { console.error(e); toast("Could not connect the call", "err"); return finish("failed"); }
  watchCandidates();
  unsubs.push(onSnapshot(callRef(), async s => {
    const x = s.data(); if (!x || ended) return;
    if (x.status === "ended" || x.status === "declined") return finish("ended");
    // caller restarted ICE (network change): answer the new offer
    if (x.rv && x.rv > lastRv && x.offer) {
      lastRv = x.rv;
      try {
        await pc.setRemoteDescription(x.offer);
        const a = await pc.createAnswer(); const ld = await setLocal(a);
        await updateDoc(callRef(), { answer: { type: ld.type, sdp: ld.sdp }, av: x.rv });
      } catch (e) { console.warn("answer restart", e); }
    }
  }));
}
function declineCall() {
  if (!incomingId) return;
  updateDoc(doc(db, "calls", incomingId), { status: "declined" }).catch(() => {});
  hideIncoming();
}

/* ---------------- end / cleanup ---------------- */
export function endCall(reason = "ended") {
  if (ended) return;
  updateDoc(callRef(), { status: reason === "declined" ? "declined" : "ended" }).catch(() => {});
  finish(reason);
}
function finish(reason) {
  if (ended) return;
  ended = true;
  stopRing(); clearTimeout(ringTimeout); clearInterval(timerI); clearInterval(statsI); clearTimeout(restartT);
  const dur = connectedAt ? Math.round((Date.now() - connectedAt) / 1000) : 0;
  if (role === "caller" && peerInfo) {
    const outcome = connectedAt ? "completed" : reason === "declined" ? "declined" : "missed";
    sendToPeer(peerInfo.id, { type: "call", callType: currentType, outcome, duration: dur }).catch(() => {});
  }
  unsubs.splice(0).forEach(u => u());
  local?.getTracks().forEach(t => t.stop()); local = null;
  screenStream?.getTracks().forEach(t => t.stop()); screenStream = null; camTrack = null;
  try { pc?.close(); } catch { /* ignore */ }
  try { wakeLock?.release(); } catch { /* ignore */ } wakeLock = null;
  pc = null; connectedAt = 0; role = null; callId = null; peerInfo = null;
  hideCallUI();
  if (reason === "ended" && dur) toast("Call ended");
}

/* ---------------- controls ---------------- */
async function swapVideoTrack(track) {
  const sender = pc?.getSenders().find(s => s.track?.kind === "video" || s._v);
  if (sender) await sender.replaceTrack(track);
}
async function flipCamera() {
  if (!local || currentType !== "video" || screenStream) return;
  facing = facing === "user" ? "environment" : "user";
  try {
    const ns = await navigator.mediaDevices.getUserMedia({ video: { ...VIDEO_CONSTRAINTS, facingMode: { exact: facing } } });
    const t = ns.getVideoTracks()[0];
    camTrack?.stop(); local.removeTrack(camTrack); local.addTrack(t); camTrack = t;
    await swapVideoTrack(t); $("#localVideo").srcObject = local;
    $("#localVideo").style.transform = facing === "user" ? "scaleX(-1)" : "none";
  } catch { facing = facing === "user" ? "environment" : "user"; toast("Could not switch camera", "err"); }
}
async function toggleShare(btn) {
  if (currentType !== "video" || !pc) return;
  const o = $("#callOverlay");
  if (screenStream) return stopShare();
  if (!navigator.mediaDevices?.getDisplayMedia) return toast("Screen sharing is not supported on this device", "err");
  try {
    screenStream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 15 }, audio: false });
    const t = screenStream.getVideoTracks()[0]; try { t.contentHint = "detail"; } catch { /* ignore */ }
    t.onended = stopShare;
    await swapVideoTrack(t);
    $("#localVideo").srcObject = screenStream; o.classList.add("screen-local"); btn.classList.add("on"); applyBitrates();
  } catch { screenStream = null; }
}
async function stopShare() {
  if (!screenStream) return;
  screenStream.getTracks().forEach(t => t.stop()); screenStream = null;
  $("#callOverlay").classList.remove("screen-local"); $("#shareBtn").classList.remove("on");
  if (camTrack && pc) { await swapVideoTrack(camTrack); $("#localVideo").srcObject = local; }
  applyBitrates();
}
export function initCallUI() {
  $("#endBtn").onclick = () => endCall("ended");
  $("#muteBtn").onclick = e => {
    const t = local?.getAudioTracks()[0]; if (!t) return;
    t.enabled = !t.enabled;
    e.currentTarget.classList.toggle("off", !t.enabled);
    e.currentTarget.innerHTML = icon(t.enabled ? "mic" : "mic-off", 24);
  };
  $("#camBtn").onclick = e => {
    const t = camTrack; if (!t) return;
    t.enabled = !t.enabled;
    e.currentTarget.classList.toggle("off", !t.enabled);
    e.currentTarget.innerHTML = icon(t.enabled ? "video" : "video-off", 24);
    $("#callOverlay").classList.toggle("local-video", t.enabled || !!screenStream);
  };
  $("#flipBtn").onclick = flipCamera;
  $("#shareBtn").onclick = e => toggleShare(e.currentTarget);
  $("#incAccept").onclick = acceptCall;
  $("#incDecline").onclick = declineCall;
  window.addEventListener("beforeunload", () => { if (!ended && callId) updateDoc(callRef(), { status: "ended" }).catch(() => {}); });
  window.addEventListener("online", () => { if (pc && role === "caller" && pc.connectionState !== "connected") restartIce(); });
}
export const inCall = () => !ended;
