import { db, updateDoc, arrayRemove } from "./firebase.js";
import { S } from "./state.js";
import { OWNER, ACCENTS, WALLPAPERS, APP_VERSION, DIVISIONS } from "./config.js";
import { $, esc, avatar, icon, toast, openModal, closeModal, makeKeywords, nameHtml, ownerBadge, copyText, injectLogos } from "./utils.js";
import { prefs, setPref, askNotifPermission, notifSupported } from "./prefs.js";
import { getUser, userRef, closeChat, stopChatList } from "./chat.js";
import { uploadFile, compressImage } from "./attach.js";
import { fillDivisionSelects, detectLocation, roundGeo, logout } from "./auth.js";
import { geohashEncode } from "./geo.js";
import { resetDiscoverCache } from "./people.js";

let installEvt = null;
window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); installEvt = e; renderSettings(); });
window.addEventListener("appinstalled", () => { installEvt = null; renderSettings(); });
const isStandalone = () => matchMedia("(display-mode: standalone)").matches || navigator.standalone;
const isIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent);

const row = (ic, color, title, sub, act, right = "") => `<button class="set-item" data-set="${act}"><span class="set-ic" style="background:${color}">${icon(ic, 18)}</span><span class="st">${title}${sub ? `<small>${sub}</small>` : ""}</span>${right || icon("chevron-right", 18)}</button>`;

export function renderSettings() {
  const m = S.me, box = $("#settingsList"); if (!box || !m) return;
  const p = prefs();
  box.innerHTML = `
    <div class="set-hero" data-set="profile">${avatar(m, 62)}<div style="flex:1;min-width:0"><b>${nameHtml({ ...m, id: S.uid })}</b><span class="muted">@${esc(m.username)}</span><div class="muted tiny" style="margin-top:2px">${esc(m.bio || "")}</div></div>${icon("chevron-right", 18)}</div>
    <div class="set-group">
      ${row("palette", "linear-gradient(135deg,#8b5cf6,#ec4899)", "Appearance", `${p.theme === "auto" ? "Auto" : p.theme[0].toUpperCase() + p.theme.slice(1)} · ${ACCENTS[p.accent]?.name}`, "appearance")}
      ${row("bell", "#f59e0b", "Notifications", p.sound ? "Sounds on" : "Sounds off", "notifications")}
      ${row("lock", "#10b981", "Privacy", "Last seen, read receipts, nearby", "privacy")}
      ${row("pin", "#0ea5e9", "Location", [m.locality, m.area].filter(Boolean).join(", ") || "Not set", "location")}
      ${row("ban", "#ef4444", "Blocked users", `${(m.blocked || []).length} blocked`, "blocked")}
    </div>
    <div class="set-group">
      ${!isStandalone() ? row("download", "#6366f1", "Install Kotha app", installEvt ? "Add to home screen / desktop" : (isIOS() ? "Share > Add to Home Screen" : "Use browser menu > Install"), "install") : ""}
      ${row("info", "#64748b", "About Kotha", `Version ${APP_VERSION} · ${OWNER.credit}`, "about")}
      ${row("logout", "#ef4444", "Log out", "", "logout", "")}
    </div>
    <div class="set-foot">${ownerBadge(14)} <b>${OWNER.credit}</b><br>© ${OWNER.year} ${OWNER.name}. All rights reserved.</div>`;
}

const swRow = (id, title, sub, on) => `<div class="set-item" style="cursor:default"><span class="st">${title}${sub ? `<small>${sub}</small>` : ""}</span><button class="sw ${on ? "on" : ""}" id="${id}" role="switch" aria-checked="${!!on}"></button></div>`;

function appearance() {
  const p = prefs();
  openModal(`<div class="mc-head"><h3>Appearance</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <label>Theme</label>
    <div class="seg" id="apTheme">${["light", "dark", "auto"].map(t => `<button data-v="${t}" class="${p.theme === t ? "on" : ""}">${t === "auto" ? "Auto" : t[0].toUpperCase() + t.slice(1)}</button>`).join("")}</div>
    <label>Accent colour</label>
    <div class="swatches" id="apAccent">${Object.entries(ACCENTS).map(([k, a]) => `<button class="swatch ${p.accent === k ? "on" : ""}" data-v="${k}" title="${a.name}" style="background:linear-gradient(135deg,${a.a1},${a.a2})"></button>`).join("")}</div>
    <label>Chat wallpaper</label>
    <div class="wp-grid" id="apWp">${Object.entries(WALLPAPERS).map(([k, n]) => `<button class="wp ${p.wallpaper === k ? "on" : ""}" data-v="${k}" style="${k === "gradient" ? "background:linear-gradient(160deg,color-mix(in srgb,var(--a1) 25%,var(--panel2)),color-mix(in srgb,var(--a2) 22%,var(--panel2)))" : k === "dots" ? "background:radial-gradient(var(--line) 1.4px,var(--panel2) 1.4px) 0 0/12px 12px" : k === "doodle" ? "background:var(--panel2)" : "background:var(--panel2)"}">${n}</button>`).join("")}</div>
    <label>Text size</label>
    <div class="seg" id="apSize">${[["0.92", "Small"], ["1", "Normal"], ["1.1", "Large"], ["1.2", "XL"]].map(([v, n]) => `<button data-v="${v}" class="${String(p.fontScale) === v ? "on" : ""}">${n}</button>`).join("")}</div>`);
  const pick = (sel, key, conv = x => x) => $(sel).addEventListener("click", e => { const b = e.target.closest("[data-v]"); if (!b) return; setPref(key, conv(b.dataset.v)); [...$(sel).children].forEach(c => c.classList.toggle("on", c === b)); renderSettings(); });
  pick("#apTheme", "theme"); pick("#apAccent", "accent"); pick("#apWp", "wallpaper"); pick("#apSize", "fontScale", Number);
  $("#modalCard").onclick = e => { if (e.target.closest("[data-x]")) closeModal(); };
}

function notifications() {
  const p = prefs(), perm = notifSupported() ? Notification.permission : "unsupported";
  openModal(`<div class="mc-head"><h3>Notifications</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <div class="set-group" style="margin:0">
      ${swRow("ntSound", "Sounds", "Message and call sounds", p.sound)}
      ${swRow("ntDesk", "Desktop / phone notifications", perm === "granted" ? "Allowed by browser" : perm === "denied" ? "Blocked in browser settings" : perm === "unsupported" ? "Not supported here" : "Tap to allow", p.desktop && perm === "granted")}
      ${swRow("ntEnter", "Enter key sends", "Shift+Enter for a new line", p.enterSend)}
    </div>`);
  const tg = (id, key, after) => $(id).onclick = async e => { const on = !prefs()[key]; setPref(key, on); e.currentTarget.classList.toggle("on", on); await after?.(on, e.currentTarget); renderSettings(); };
  tg("#ntSound", "sound"); tg("#ntEnter", "enterSend");
  $("#ntDesk").onclick = async e => {
    const b = e.currentTarget;
    if (!notifSupported()) return toast("Not supported on this browser", "err");
    const r = await askNotifPermission();
    if (r === "granted") { setPref("desktop", !(b.classList.contains("on"))); b.classList.toggle("on"); }
    else toast("Please allow notifications in your browser settings", "err");
  };
  $("#modalCard").onclick = e => { if (e.target.closest("[data-x]")) closeModal(); };
}

function privacy() {
  const pr = S.me.privacy || {};
  const state = { lastSeen: pr.lastSeen !== "nobody", readReceipts: pr.readReceipts !== false, showLocation: pr.showLocation !== false };
  openModal(`<div class="mc-head"><h3>Privacy</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <div class="set-group" style="margin:0">
      ${swRow("pvSeen", "Show last seen & online", "If off, you will not see others' either", state.lastSeen)}
      ${swRow("pvRead", "Read receipts", "Blue ticks when you read messages", state.readReceipts)}
      ${swRow("pvLoc", "Appear in Nearby", "Others can find you by approximate distance", state.showLocation)}
    </div>
    <p class="muted tiny center">Your exact position is never shared. Nearby uses a rounded area of about 1 km.</p>`);
  const save = () => updateDoc(userRef(), { privacy: { lastSeen: state.lastSeen ? "everyone" : "nobody", readReceipts: state.readReceipts, showLocation: state.showLocation } }).then(() => { resetDiscoverCache(); renderSettings(); }).catch(() => toast("Could not save", "err"));
  [["#pvSeen", "lastSeen"], ["#pvRead", "readReceipts"], ["#pvLoc", "showLocation"]].forEach(([id, k]) => { $(id).onclick = e => { state[k] = !state[k]; e.currentTarget.classList.toggle("on", state[k]); save(); }; });
  $("#modalCard").onclick = e => { if (e.target.closest("[data-x]")) closeModal(); };
}

function locationModal() {
  const m = S.me;
  openModal(`<div class="mc-head"><h3>Location</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <p class="muted tiny">Used to show people near you. Only an approximate area is stored.</p>
    <button class="btn-secondary" id="lcGps">${icon("locate", 16)} Use my current location</button>
    <div class="two"><label>Division<select id="lcDiv"></select></label><label>District<select id="lcArea"></select></label></div>
    <label>Locality<input id="lcLoc" maxlength="40" value="${esc(m.locality || "")}" placeholder="Town / upazila / neighbourhood"></label>
    <small id="lcNote" class="muted"></small>
    <button class="btn-primary" id="lcSave">Save location</button>`);
  fillDivisionSelects($("#lcDiv"), $("#lcArea"), m.division || "", m.area || "");
  let geo = null;
  $("#modalCard").onclick = async e => {
    if (e.target.closest("[data-x]")) return closeModal();
    if (e.target.closest("#lcGps")) { const r = await detectLocation({ divSel: $("#lcDiv"), areaSel: $("#lcArea"), locInput: $("#lcLoc"), note: $("#lcNote"), btn: $("#lcGps") }); if (r) geo = r; return; }
    if (e.target.closest("#lcSave")) {
      const area = $("#lcArea").value; if (!area) return toast("Select your district", "err");
      const upd = { area, division: $("#lcDiv").value === "Other" ? "" : $("#lcDiv").value, locality: $("#lcLoc").value.trim() };
      if (geo) { upd.geo = roundGeo(geo.lat, geo.lng); upd.geohash = geohashEncode(geo.lat, geo.lng, 6); }
      await updateDoc(userRef(), upd).then(() => { toast("Location saved", "ok"); resetDiscoverCache(); closeModal(); }).catch(() => toast("Could not save", "err"));
    }
  };
}

async function blockedModal() {
  const ids = S.me.blocked || [];
  const us = (await Promise.all(ids.map(id => getUser(id, 60000)))).filter(Boolean);
  openModal(`<div class="mc-head"><h3>Blocked users</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <div class="pick-list">${us.map(u => `<div class="pick" style="cursor:default">${avatar(u, 40)}<span class="pn">${esc(u.displayName)}<small>@${esc(u.username || "")}</small></span><button class="chip-btn" data-ub="${u.id}">Unblock</button></div>`).join("") || '<div class="empty-note">You have not blocked anyone.</div>'}</div>`);
  $("#modalCard").onclick = async e => {
    if (e.target.closest("[data-x]")) return closeModal();
    const b = e.target.closest("[data-ub]"); if (!b) return;
    await updateDoc(userRef(), { blocked: arrayRemove(b.dataset.ub) }).catch(() => {}); b.closest(".pick").remove(); toast("Unblocked");
  };
}

function about() {
  openModal(`<div class="about-card"><div class="logo-anim" data-logo></div><h3 style="margin-top:2px">Kotha</h3>
    <p class="muted">Version ${APP_VERSION}</p>
    <p style="font-size:16px;font-weight:700">${OWNER.credit}</p>
    <div class="owner-proof"><b>${ownerBadge(17)} Verified Owner &amp; Developer</b>
      ${esc(OWNER.name)} designed, built and owns Kotha. Unauthorised copying, re-branding or re-selling of this app is not permitted.
      <div style="margin-top:10px">
        <div class="kv"><span>Owner</span><code>${esc(OWNER.name)}</code></div>
        <div class="kv"><span>Product</span><code>Kotha - HD calls, chat &amp; meetings</code></div>
        <div class="kv"><span>Copyright</span><code>© ${OWNER.year} ${esc(OWNER.name)}</code></div>
        ${S.isOwner ? `<div class="kv"><span>You</span><code>Signed in as verified owner ✔</code></div><div class="kv"><span>Your UID</span><code id="abUid">${esc(S.uid)}</code></div>` : ""}
      </div>
    </div>
    ${S.isOwner ? `<button class="btn-secondary" id="abCopy">${icon("copy", 15)} Copy my UID (for the badge, see README)</button>` : ""}
    <button class="btn-primary" data-x style="align-self:stretch">Close</button></div>`);
  injectLogos($("#modalCard"));
  $("#modalCard").onclick = async e => {
    if (e.target.closest("[data-x]")) return closeModal();
    if (e.target.closest("#abCopy")) toast(await copyText(S.uid) ? "UID copied" : "Copy failed");
  };
}

function install() {
  if (installEvt) { installEvt.prompt(); installEvt.userChoice.finally(() => { installEvt = null; renderSettings(); }); return; }
  openModal(`<div class="mc-head"><h3>Install Kotha</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <p>${isIOS() ? "On iPhone/iPad: tap the <b>Share</b> button in Safari, then <b>Add to Home Screen</b>." : "In Chrome: open the browser menu (⋮) and choose <b>Install app</b> / <b>Add to Home screen</b>."}</p>
    <p class="muted tiny">Kotha will open full-screen like a normal app, with notifications.</p>`);
  $("#modalCard").onclick = e => { if (e.target.closest("[data-x]")) closeModal(); };
}

export function showMyProfile() {
  const m = S.me;
  openModal(`<div class="mc-head"><h3>Your profile</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <div style="position:relative;align-self:center" id="myAvWrap">${avatar(m, 100)}<button class="send-btn" id="chPhoto" style="position:absolute;right:-6px;bottom:-6px;width:36px;height:36px">${icon("camera", 18)}</button></div>
    <input type="file" id="photoInput" accept="image/*" class="hidden">
    <label>Name<input id="pfName" maxlength="40" value="${esc(m.displayName)}"></label>
    <label>Bio<input id="pfBio" maxlength="80" value="${esc(m.bio || "")}"></label>
    <p class="muted tiny center">@${esc(m.username)} · ${[m.locality, m.area].filter(Boolean).join(", ")}</p>
    <div class="row"><button class="btn-secondary" data-pm="close">Cancel</button><button class="btn-primary" data-pm="save">Save</button></div>`);
  let photo = m.photoURL || "";
  $("#chPhoto").onclick = () => $("#photoInput").click();
  $("#photoInput").onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    try { const up = await uploadFile(await compressImage(f, 600), "photo"); photo = up.secure_url; $("#myAvWrap").firstElementChild.outerHTML = avatar({ displayName: m.displayName, photoURL: photo }, 100); }
    catch (er) { toast(er.message, "err"); }
  };
  $("#modalCard").onclick = async e => {
    if (e.target.closest("[data-x]")) return closeModal();
    const a = e.target.closest("[data-pm]")?.dataset.pm; if (!a) return;
    if (a === "close") closeModal();
    else if (a === "save") {
      const name = $("#pfName").value.trim(); if (name.length < 2) return toast("Enter your name", "err");
      await updateDoc(userRef(), { displayName: name, nameLower: name.toLowerCase(), keywords: makeKeywords(name, m.username), bio: $("#pfBio").value.trim(), photoURL: photo })
        .then(() => { toast("Profile updated", "ok"); closeModal(); }).catch(() => toast("Could not save", "err"));
    }
  };
}

export function initSettings() {
  $("#settingsList").addEventListener("click", e => {
    const a = e.target.closest("[data-set]")?.dataset.set; if (!a) return;
    ({ profile: showMyProfile, appearance, notifications, privacy, location: locationModal, blocked: blockedModal, about, install,
      logout: () => { if (confirm("Log out of Kotha?")) { closeChat(); stopChatList(); logout(); } } })[a]?.();
  });
  renderSettings();
}
export { about as showAbout };
