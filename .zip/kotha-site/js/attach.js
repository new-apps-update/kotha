import { S } from "./state.js";
import { CLOUDINARY, MAX_MB } from "./config.js";
import { $, $$, esc, icon, toast, openModal, closeModal, fileKind, fileExt, fmtSize, docTone, rid, haptic } from "./utils.js";
import { sendToCurrent } from "./chat.js";
import { getPosition, reverseGeocode, mapHtml } from "./geo.js";

/* =====================  UPLOAD (Cloudinary)  ===================== */
export async function compressImage(file, maxDim = 1600, quality = .82) {
  try {
    if (!file.type.startsWith("image/") || /gif|svg/.test(file.type) || file.size < 350 * 1024) return file;
    const bmp = await createImageBitmap(file, { imageOrientation: "from-image" });
    const k = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
    const w = Math.round(bmp.width * k), h = Math.round(bmp.height * k);
    const cv = document.createElement("canvas"); cv.width = w; cv.height = h;
    cv.getContext("2d").drawImage(bmp, 0, 0, w, h);
    const blob = await new Promise(r => cv.toBlob(r, "image/jpeg", quality));
    if (!blob || blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.\w+$/, "") + ".jpg", { type: "image/jpeg" });
  } catch { return file; }
}

export function uploadFile(file, label) {
  return new Promise((res, rej) => {
    const kind = fileKind(file.name, file.type), lim = MAX_MB[kind] || 10;
    if (file.size > lim * 1024 * 1024) return rej(new Error(`${file.name || "File"} is too large (max ${lim} MB for ${kind === "file" ? "documents" : kind + "s"})`));
    const bar = $("#uploadBar"), fill = $("#uploadFill");
    $("#uploadName").textContent = "Uploading " + (label || file.name) + "...";
    fill.style.width = "0"; bar.classList.remove("hidden");
    const fd = new FormData();
    fd.append("file", file); fd.append("upload_preset", CLOUDINARY.uploadPreset);
    const x = new XMLHttpRequest();
    x.open("POST", `https://api.cloudinary.com/v1_1/${CLOUDINARY.cloudName}/auto/upload`);
    x.upload.onprogress = e => { if (e.lengthComputable) fill.style.width = (e.loaded / e.total * 100) + "%"; };
    x.onload = () => {
      bar.classList.add("hidden");
      try {
        const j = JSON.parse(x.responseText);
        if (x.status >= 200 && x.status < 300 && j.secure_url) res(j);
        else rej(new Error(j.error?.message || "Upload failed"));
      } catch { rej(new Error("Upload failed")); }
    };
    x.onerror = () => { bar.classList.add("hidden"); rej(new Error("Network error during upload")); };
    x.send(fd);
  });
}

async function sendFileMsg(file, caption) {
  const kind = fileKind(file.name, file.type);
  const f = kind === "image" ? await compressImage(file) : file;
  const up = await uploadFile(f);
  // Cloudinary sometimes classifies audio/pdf as "video"/"image": trust our own detection
  const payload = { type: kind, url: up.secure_url, fileName: file.name, size: f.size };
  if (caption) payload.text = caption;
  if (kind === "video" && up.duration) payload.duration = Math.round(up.duration);
  return sendToCurrent(payload);
}

/* =====================  PREVIEW BEFORE SEND  ===================== */
export function showFilePreview(files) {
  files = [...files].filter(f => f.size >= 0);
  if (!files.length || !S.chatId) return;
  let idx = 0;
  const urls = files.map(f => fileKind(f.name, f.type) === "image" || fileKind(f.name, f.type) === "video" ? URL.createObjectURL(f) : "");
  const paint = () => {
    const f = files[idx], k = fileKind(f.name, f.type);
    const big = k === "image" ? `<img class="img-preview" src="${urls[idx]}" alt="">`
      : k === "video" ? `<video class="img-preview" src="${urls[idx]}" controls playsinline style="width:100%"></video>`
      : `<div class="file-card" style="background:var(--panel2);align-self:stretch"><i class="fi" style="background:${docTone(fileExt(f.name))}">${icon("file", 18)}${esc((fileExt(f.name) || "file").toUpperCase())}</i><span class="fx"><span class="fn">${esc(f.name)}</span><span class="fs">${fmtSize(f.size)}</span></span></div>`;
    $("#fpBody").innerHTML = big + (files.length > 1 ? `<div class="thumbs">${files.map((g, i) => `<div class="${i === idx ? "on " : ""}tdoc" data-t="${i}" style="${urls[i] && fileKind(g.name, g.type) === "image" ? `background:url(${urls[i]}) center/cover` : ""}">${urls[i] && fileKind(g.name, g.type) === "image" ? "" : esc((fileExt(g.name) || "file").toUpperCase())}</div>`).join("")}</div>` : "");
  };
  openModal(`<div class="mc-head"><h3>Send ${files.length > 1 ? files.length + " files" : "file"}</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <div id="fpBody" style="display:flex;flex-direction:column;gap:10px"></div>
    <input id="fpCap" maxlength="300" placeholder="Add a caption (optional)">
    <button class="btn-primary" id="fpSend">Send</button>`, "wide");
  paint();
  const clean = () => urls.forEach(u => u && URL.revokeObjectURL(u));
  $("#modalCard").onclick = async e => {
    if (e.target.closest("[data-x]")) { clean(); return closeModal(); }
    const t = e.target.closest("[data-t]"); if (t) { idx = +t.dataset.t; paint(); return; }
    if (e.target.closest("#fpSend")) {
      const cap = $("#fpCap").value.trim(); clean(); closeModal();
      for (let i = 0; i < files.length; i++) {
        try { await sendFileMsg(files[i], i === 0 ? cap : ""); } catch (er) { toast(er.message || "Upload failed", "err"); }
      }
    }
  };
  $("#fpCap").addEventListener("keydown", e => { if (e.key === "Enter") $("#fpSend").click(); });
  setTimeout(() => $("#fpCap")?.focus(), 50);
}

/* =====================  LOCATION  ===================== */
async function shareLocation() {
  openModal(`<div class="mc-head"><h3>Share location</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <div class="loc-pick"><div id="lpMap" class="skeleton" style="height:170px;margin:0"></div></div>
    <p id="lpTxt" class="muted center tiny">Getting your current location...</p>
    <input id="lpLabel" maxlength="80" placeholder="Add a note (optional)">
    <button class="btn-primary" id="lpSend" disabled>Send current location</button>`);
  const c = $("#modalCard"); let pos = null, label = "";
  c.onclick = async e => {
    if (e.target.closest("[data-x]")) return closeModal();
    if (e.target.closest("#lpSend") && pos) {
      const note = $("#lpLabel").value.trim();
      closeModal();
      await sendToCurrent({ type: "location", lat: Math.round(pos.lat * 1e5) / 1e5, lng: Math.round(pos.lng * 1e5) / 1e5, label: note || label || "Shared location" });
    }
  };
  try {
    pos = await getPosition();
    $("#lpMap").outerHTML = mapHtml(pos.lat, pos.lng, Math.min(440, $("#modalCard").clientWidth - 52), 170, 16);
    const g = await reverseGeocode(pos.lat, pos.lng);
    label = [g.locality, g.district].filter(Boolean).join(", ");
    $("#lpTxt").textContent = `📍 ${label || pos.lat.toFixed(4) + ", " + pos.lng.toFixed(4)}  ·  accuracy ~${Math.round(pos.acc)} m`;
    $("#lpSend").disabled = false;
  } catch (e) { $("#lpTxt").textContent = e.message; $("#lpMap")?.remove(); }
}

/* =====================  POLL  ===================== */
function createPoll() {
  openModal(`<div class="mc-head"><h3>Create poll</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <label>Question<input id="plQ" maxlength="120" placeholder="Ask something..."></label>
    <label>Options<div id="plOpts" style="display:flex;flex-direction:column;gap:8px"></div></label>
    <button class="chip-btn" id="plAdd" style="align-self:flex-start">${icon("plus", 14)} Add option</button>
    <label style="flex-direction:row;align-items:center;gap:10px"><span class="sw" id="plMulti"></span> Allow multiple answers</label>
    <button class="btn-primary" id="plSend">Send poll</button>`);
  const opts = $("#plOpts"); let multi = false;
  const add = () => { if (opts.children.length >= 8) return; const i = document.createElement("input"); i.maxLength = 60; i.placeholder = "Option " + (opts.children.length + 1); opts.appendChild(i); };
  add(); add();
  $("#modalCard").onclick = async e => {
    if (e.target.closest("[data-x]")) return closeModal();
    if (e.target.closest("#plAdd")) return add();
    if (e.target.closest("#plMulti")) { multi = !multi; $("#plMulti").classList.toggle("on", multi); return; }
    if (e.target.closest("#plSend")) {
      const question = $("#plQ").value.trim();
      const options = $$("#plOpts input").map(i => i.value.trim()).filter(Boolean).map(text => ({ id: rid(5), text }));
      if (!question) return toast("Write a question", "err");
      if (options.length < 2) return toast("Add at least 2 options", "err");
      closeModal();
      await sendToCurrent({ type: "poll", question, options, multi, votes: {} });
    }
  };
}

/* =====================  WIRING  ===================== */
export function initAttach() {
  const menu = $("#attachMenu");
  const items = [
    ["image", "Photos & videos", "#7c3aed", () => $("#mediaInput").click()],
    ["camera", "Camera", "#ec4899", () => $("#camInput").click()],
    ["file", "Document", "#2563eb", () => $("#fileInput").click()],
    ["pin", "Location", "#16a34a", shareLocation],
    ["poll", "Poll", "#f59e0b", createPoll]
  ];
  menu.innerHTML = items.map((x, i) => `<button class="am-item" data-i="${i}"><i style="background:${x[2]}">${icon(x[0], 22)}</i><span>${x[1]}</span></button>`).join("");
  menu.addEventListener("click", e => { const b = e.target.closest("[data-i]"); if (!b) return; menu.classList.add("hidden"); items[+b.dataset.i][3](); });
  $("#attachBtn").onclick = e => { e.stopPropagation(); $("#emojiPanel").classList.add("hidden"); menu.classList.toggle("hidden"); haptic(8); };
  ["#fileInput", "#mediaInput", "#camInput"].forEach(s => $(s).onchange = e => { const f = [...e.target.files]; e.target.value = ""; if (f.length) showFilePreview(f); });

  // drag & drop
  const cv = $("#chatView"); let depth = 0;
  cv.addEventListener("dragenter", e => { if (e.dataTransfer?.types?.includes("Files")) { depth++; $("#dropHint").classList.remove("hidden"); } });
  cv.addEventListener("dragleave", () => { depth = Math.max(0, depth - 1); if (!depth) $("#dropHint").classList.add("hidden"); });
  cv.addEventListener("dragover", e => { if (e.dataTransfer?.types?.includes("Files")) e.preventDefault(); });
  cv.addEventListener("drop", e => { e.preventDefault(); depth = 0; $("#dropHint").classList.add("hidden"); if (e.dataTransfer?.files?.length) showFilePreview(e.dataTransfer.files); });
  // paste images
  $("#msgInput").addEventListener("paste", e => {
    const fs = [...(e.clipboardData?.files || [])]; if (fs.length) { e.preventDefault(); showFilePreview(fs); }
  });
}
