import {
  auth, db, googleProvider, signInWithPopup, signInWithRedirect, getRedirectResult,
  onAuthStateChanged, signOut, doc, getDoc, setDoc, getDocs, collection, query, where, limit, serverTimestamp
} from "./firebase.js";
import { DIVISIONS, OWNER } from "./config.js";
import { S } from "./state.js";
import { $, avatar, toast, makeKeywords, injectIcons, setOwnerSelf, ownerBadge } from "./utils.js";
import { geohashEncode, getPosition, reverseGeocode, divisionOf } from "./geo.js";

const show = id => { ["#login", "#onboard"].forEach(s => $(s).classList.add("hidden")); if (id) $(id).classList.remove("hidden"); };

export function fillDivisionSelects(divSel, areaSel, div = "", area = "") {
  divSel.innerHTML = '<option value="">Select division</option>' + Object.keys(DIVISIONS).map(d => `<option ${d === div ? "selected" : ""}>${d}</option>`).join("") + '<option value="Other">Other / outside Bangladesh</option>';
  const fillAreas = () => {
    const d = divSel.value;
    const list = d === "Other" ? ["Other"] : (DIVISIONS[d] || []).map(x => x[0]);
    areaSel.innerHTML = '<option value="">Select district</option>' + list.map(a => `<option>${a}</option>`).join("");
    if (list.includes(area)) areaSel.value = area;
    area = "";
  };
  divSel.onchange = fillAreas;
  fillAreas();
}

// Detect + apply GPS to a pair of selects; returns {lat,lng,...}
export async function detectLocation({ divSel, areaSel, locInput, note, btn }) {
  const old = btn?.innerHTML; if (btn) { btn.disabled = true; btn.innerHTML = "Locating..."; }
  try {
    const p = await getPosition();
    const g = await reverseGeocode(p.lat, p.lng);
    if (g.district) {
      divSel.value = g.division; divSel.onchange?.();
      areaSel.value = g.district;
    }
    if (locInput && g.locality && !locInput.value) locInput.value = g.locality;
    if (note) note.textContent = `📍 Detected ${[g.locality, g.district].filter(Boolean).join(", ")}. Only an approximate area (about 1 km) is shared.`;
    return { lat: p.lat, lng: p.lng, ...g };
  } catch (e) {
    toast(e.message || "Could not get your location", "err");
    return null;
  } finally { if (btn) { btn.disabled = false; btn.innerHTML = old; } }
}
export const roundGeo = (lat, lng) => ({ lat: Math.round(lat * 100) / 100, lng: Math.round(lng * 100) / 100 });

export function initAuth({ onReady, onLoggedOut }) {
  $$owner();
  getRedirectResult(auth).catch(e => { if (e?.code && e.code !== "auth/no-auth-event") console.warn(e); });

  const gbtn = $("#googleBtn");
  gbtn.addEventListener("click", async () => {
    gbtn.classList.add("loading"); gbtn.disabled = true;
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (e) {
      if (e.code === "auth/popup-blocked" || e.code === "auth/operation-not-supported-in-this-environment") {
        try { await signInWithRedirect(auth, googleProvider); return; } catch (e2) { e = e2; }
      }
      if (e.code === "auth/unauthorized-domain") toast("This website's domain is not authorized in Firebase yet.", "err", 6000);
      else if (e.code !== "auth/popup-closed-by-user" && e.code !== "auth/cancelled-popup-request") toast("Login failed: " + (e.code || e.message), "err");
    } finally { gbtn.classList.remove("loading"); gbtn.disabled = false; }
  });

  $("#obLogout").addEventListener("click", () => signOut(auth));

  onAuthStateChanged(auth, async user => {
    if (!user) { show("#login"); onLoggedOut(); return; }
    S.isOwner = (user.email || "").toLowerCase() === OWNER.email.toLowerCase();
    setOwnerSelf(S.isOwner ? user.uid : null);
    try {
      const snap = await getDoc(doc(db, "users", user.uid));
      const data = snap.exists() ? snap.data() : null;
      if (!data || !data.username) { showOnboarding(user, data, onReady); return; }
      show(null);
      onReady(user, data);
    } catch (e) {
      console.error(e);
      toast("Could not load your profile. Check Firestore rules and database.", "err", 6000);
      show("#login");
    }
  });
}
function $$owner() { document.querySelectorAll("[data-owner-badge]").forEach(e => { e.innerHTML = ownerBadge(15); }); }

function showOnboarding(user, existing, onReady) {
  show("#onboard");
  $("#obAvatar").innerHTML = avatar({ displayName: user.displayName, photoURL: user.photoURL }, 88);
  $("#obName").value = existing?.displayName || user.displayName || "";
  const base = (user.email || user.displayName || "user").split("@")[0].toLowerCase().replace(/[^a-z0-9_.]/g, "").slice(0, 14);
  $("#obUser").value = existing?.username || (base.length >= 3 ? base : "user" + Math.floor(Math.random() * 9000 + 1000));
  const divSel = $("#obDiv"), sel = $("#obArea"), loc = $("#obLocality"), note = $("#obGeoNote");
  fillDivisionSelects(divSel, sel, existing?.division || divisionOf(existing?.area), existing?.area || "");
  loc.value = existing?.locality || "";
  note.textContent = "Tip: tap “Use my location” to find people near you automatically.";
  $("#obError").textContent = "";
  let geo = null;
  $("#obGps").onclick = async () => { const r = await detectLocation({ divSel, areaSel: sel, locInput: loc, note, btn: $("#obGps") }); if (r) geo = r; };
  const btn = $("#obSave");
  btn.disabled = false;
  btn.onclick = async () => {
    const name = $("#obName").value.trim();
    const username = $("#obUser").value.trim().toLowerCase().replace(/^@/, "");
    const area = sel.value;
    const err = m => { $("#obError").textContent = m; };
    if (name.length < 2) return err("Please enter your name.");
    if (!/^[a-z0-9_.]{3,20}$/.test(username)) return err("Username: 3-20 letters, numbers, dot or underscore.");
    if (!area) return err("Please select your district.");
    btn.disabled = true; err("");
    try {
      const q = query(collection(db, "users"), where("usernameLower", "==", username), limit(1));
      const found = await getDocs(q);
      if (!found.empty && found.docs[0].id !== user.uid) { err("This username is taken. Try another one."); btn.disabled = false; return; }
      const profile = {
        uid: user.uid, displayName: name, nameLower: name.toLowerCase(),
        username, usernameLower: username, keywords: makeKeywords(name, username),
        photoURL: user.photoURL || "", area, division: divSel.value === "Other" ? "" : divSel.value, locality: loc.value.trim(),
        bio: "Hey there! I am on Kotha 👋",
        online: true, lastSeen: serverTimestamp()
      };
      if (geo) { profile.geo = roundGeo(geo.lat, geo.lng); profile.geohash = geohashEncode(geo.lat, geo.lng, 6); }
      if (!existing) Object.assign(profile, { contacts: [], blocked: [], createdAt: serverTimestamp() });
      await setDoc(doc(db, "users", user.uid), profile, { merge: true });
      const fresh = await getDoc(doc(db, "users", user.uid));
      show(null);
      onReady(user, fresh.data());
    } catch (e) {
      console.error(e);
      err("Could not save profile: " + (e.code || e.message));
      btn.disabled = false;
    }
  };
  injectIcons();
}

export const logout = () => signOut(auth);
