import { db, doc, updateDoc, collection, query, where, orderBy, limit, getDocs, startAt, endAt } from "./firebase.js";
import { S } from "./state.js";
import { $, $$, esc, avatar, icon, toast, isOnline, nameHtml } from "./utils.js";
import { cacheUser, userRef } from "./chat.js";
import { geohashCells, geohashEncode, distanceKm, fmtDistance, getPosition, reverseGeocode } from "./geo.js";
import { roundGeo } from "./auth.js";

export const personCard = (u, extra = "") => `<div class="person" data-uid="${u.id}">
  <div class="av-wrap" data-profile="${u.id}">${avatar(u, 48)}${isOnline(u) ? '<i class="dot"></i>' : ""}</div>
  <div class="p-main"><div class="p-name">${nameHtml(u)}</div><div class="p-sub">@${esc(u.username)}${u.locality ? " · " + esc(u.locality) : ""}</div>${extra}</div>
  <button class="go-btn" data-chat="${u.id}">Message</button></div>`;

const pull = async q => { try { return (await getDocs(q)).docs.map(d => cacheUser({ id: d.id, ...d.data() })); } catch (e) { console.warn(e); return []; } };

export async function searchPeople(raw) {
  const q = raw.toLowerCase().replace(/^@/, ""), tokens = q.split(/\s+/).filter(Boolean);
  const list = await pull(query(collection(db, "users"), where("keywords", "array-contains", tokens[0].slice(0, 14)), limit(25)));
  const blocked = new Set(S.me.blocked || []);
  return list.filter(u => u.id !== S.uid && !blocked.has(u.id) && !(u.blocked || []).includes(S.uid))
    .filter(u => tokens.every(t => (u.nameLower || "").includes(t) || (u.usernameLower || "").includes(t)));
}

/* ---------- Discover ---------- */
let filter = "near", loadedAt = 0, loadedFor = "";
export function setPeopleFilter(f) {
  filter = f;
  $$("#peopleFilters .fchip").forEach(c => c.classList.toggle("active", c.dataset.pf === f));
  loadDiscover(true);
}
const ok = u => u.id !== S.uid && !(S.me.blocked || []).includes(u.id) && !(u.blocked || []).includes(S.uid) && u.username;

function renderLocBar() {
  const m = S.me, bar = $("#locBar");
  if (m.geo) {
    bar.innerHTML = `<div class="loc-card"><span class="lc-i">${icon("pin", 18)}</span><div class="lc-t"><b>${esc(m.locality ? m.locality + ", " : "")}${esc(m.area || "")}</b><span class="muted tiny">${m.privacy?.showLocation === false ? "Hidden from Nearby" : "Visible to people nearby (approx. 1 km)"}</span></div><button class="chip-btn" id="locUpdate">${icon("locate", 14)} Update</button></div>`;
  } else {
    bar.innerHTML = `<div class="loc-card"><span class="lc-i">${icon("locate", 18)}</span><div class="lc-t"><b>Find people near you</b><span class="muted tiny">Turn on location to see nearby people</span></div><button class="chip-btn" id="locUpdate">Enable</button></div>`;
  }
}

export async function updateMyLocation(silent) {
  try {
    const p = await getPosition();
    const g = await reverseGeocode(p.lat, p.lng);
    const upd = { geo: roundGeo(p.lat, p.lng), geohash: geohashEncode(p.lat, p.lng, 6) };
    if (g.district) { upd.area = g.district; upd.division = g.division; }
    if (g.locality) upd.locality = g.locality;
    await updateDoc(userRef(), upd);
    if (!silent) toast(`Location updated: ${[g.locality, g.district].filter(Boolean).join(", ")}`, "ok");
    return true;
  } catch (e) { if (!silent) toast(e.message || "Could not update location", "err"); return false; }
}

export async function loadDiscover(force = false) {
  const box = $("#discoverList");
  renderLocBar();
  const key = filter + "|" + (S.me.geohash || "") + "|" + (S.me.area || "");
  if (!force && Date.now() - loadedAt < 45000 && box.children.length && loadedFor === key) return;
  box.innerHTML = '<div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div>';
  const me = S.me, contacts = new Set(me.contacts || []);
  let html = "";
  const shown = new Set();
  const take = list => list.filter(ok).filter(u => !shown.has(u.id) && shown.add(u.id));
  const tagFor = u => `${u.area ? `<span class="tag area">${esc(u.area)}</span>` : ""}`;

  if (filter === "near") {
    if (!me.geo) {
      box.innerHTML = `<div class="empty-note"><div class="ic">📍</div><p>Enable your location to see people near you.</p><p style="margin-top:14px"><button class="btn-primary" style="padding:12px 22px" id="locEnable2">Enable location</button></p></div>`;
    } else {
      let cells = geohashCells(me.geo.lat, me.geo.lng, 4), list = [];
      const run = async cs => (await Promise.all(cs.map(c => pull(query(collection(db, "users"), orderBy("geohash"), startAt(c), endAt(c + ""), limit(30)))))).flat();
      list = await run(cells);
      if (take(list).length < 6) { shown.clear(); list = [...list, ...await run(geohashCells(me.geo.lat, me.geo.lng, 3))]; }
      shown.clear();
      const near = take(list).filter(u => u.geo && u.privacy?.showLocation !== false)
        .map(u => ({ u, km: distanceKm(me.geo, u.geo) })).sort((a, b) => a.km - b.km).slice(0, 40);
      html = near.length ? `<div class="section-title">Nearby · closest first</div>` + near.map(({ u, km }) => personCard(u, `<span class="tag dist">${fmtDistance(km)}</span>${tagFor(u)}`)).join("") : "";
      box.innerHTML = html || `<div class="empty-note"><div class="ic">🛰️</div><p>No one nearby yet.<br>Try <b>My district</b> or <b>New</b>, or invite friends to join Kotha.</p></div>`;
    }
  } else if (filter === "district") {
    const list = me.area && me.area !== "Other" ? await pull(query(collection(db, "users"), where("area", "==", me.area), limit(50))) : [];
    const u2 = take(list);
    html = u2.length ? `<div class="section-title">People in ${esc(me.area)}</div>` + u2.map(u => personCard(u, (u.locality ? `<span class="tag">${esc(u.locality)}</span>` : "") + (contacts.has(u.id) ? '<span class="tag area">Contact</span>' : ""))).join("") : "";
    box.innerHTML = html || `<div class="empty-note"><div class="ic">🏘️</div><p>No one else in ${esc(me.area || "your district")} yet.</p></div>`;
  } else if (filter === "mutual") {
    const list = contacts.size ? await pull(query(collection(db, "users"), where("contacts", "array-contains-any", [...contacts].slice(0, 10)), limit(40))) : [];
    const mut = take(list).filter(u => !contacts.has(u.id)).map(u => ({ u, n: (u.contacts || []).filter(c => contacts.has(c)).length })).sort((a, b) => b.n - a.n);
    html = mut.length ? `<div class="section-title">Mutual connections</div>` + mut.map(({ u, n }) => personCard(u, `<span class="tag">${n} mutual</span>${tagFor(u)}`)).join("") : "";
    box.innerHTML = html || `<div class="empty-note"><div class="ic">🤝</div><p>No mutual connections yet.<br>Chat with more people to see suggestions here.</p></div>`;
  } else {
    const list = await pull(query(collection(db, "users"), orderBy("createdAt", "desc"), limit(30)));
    const n = take(list).filter(u => !contacts.has(u.id)).slice(0, 20);
    html = n.length ? `<div class="section-title">New on Kotha</div>` + n.map(u => personCard(u, tagFor(u))).join("") : "";
    box.innerHTML = html || `<div class="empty-note"><div class="ic">🌍</div><p>No suggestions yet.<br>Invite your friends to join Kotha, or search by name or username.</p></div>`;
  }
  loadedAt = Date.now(); loadedFor = key;
}

export function initPeople() {
  $("#peopleFilters").addEventListener("click", e => { const b = e.target.closest("[data-pf]"); if (b) setPeopleFilter(b.dataset.pf); });
  $("#refreshPeople").onclick = () => loadDiscover(true);
  const enable = async e => {
    const b = e.target.closest("#locUpdate,#locEnable2"); if (!b) return;
    b.disabled = true;
    if (await updateMyLocation()) loadDiscover(true);
    b.disabled = false;
  };
  $("#locBar").addEventListener("click", enable);
  $("#discoverList").addEventListener("click", enable);
}
export const resetDiscoverCache = () => { loadedAt = 0; };
