==========================================================
 KOTHA v2  -  A app by Md. Fardin Fahim
==========================================================

NETLIFY E UPDATE
  Ei folder (ba zip) ta Netlify te drag-drop koro. Kono build lagbe na.

EKTA-ER-BESHI KAJ (1 minute, ekbar-i)  -> Group + Meeting er jonno
  1) Firebase Console > Firestore Database > Rules
  2) firestore.rules file er shob likha copy kore paste koro > Publish
  (1:1 chat, call, login age-er moto kono change chhara-i cholbe. Rules na dile
   shudhu "Group" ar "Meeting" create korte gele permission message dekhabe.)

DOCUMENT (PDF/ZIP) PATHANO
  Cloudinary > Settings > Security > "Restricted media types" theke
  "PDF and ZIP files delivery" ke ENABLE (Allow) koro. Na korle PDF khulbe na.

CALL QUALITY (shobcheye boro upay)
  js/config.js e TURN_SERVERS e ekta TURN server dao (Cloudflare Realtime TURN /
  Metered.ca free plan). Eta thakle mobile data <-> WiFi te-o call connect hobe.

OWNER BADGE
  Tumi (mdfardinfahim.me@gmail.com) login korle nijer name er pashe blue verified
  badge dekhabe. Sobar kache dekhate: Settings > About > "Copy my UID" kore
  js/config.js e OWNER.uids = ["tomar-uid"] boshao.

NOTUN FEATURE
  HD video calls (720p), noise-suppression, auto-reconnect, call-quality bars,
  screen share, camera flip | Group chat (admin, add/remove, photo) | Group meeting
  (8 jon porjonto, invite link, raise hand, reaction, screen share, speaking
  highlight) | Photo/Video/Document/Location/Poll pathano, preview + caption,
  drag&drop, paste | Voice note waveform + 1.5x/2x speed | Reply (swipe), forward,
  pin message, in-chat search, reactions | Pin/Mute/Archive chat | GPS Nearby
  (distance soho) + division/district | Appearance: theme, 6 accent colour,
  wallpaper, text size | Privacy: last seen, read receipts, nearby | PWA install,
  notification, offline cache | Verified owner credit.
